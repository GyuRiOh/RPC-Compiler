#include "Crash.h"


long server_baby::CrashDump::dumpCount_ = 0;